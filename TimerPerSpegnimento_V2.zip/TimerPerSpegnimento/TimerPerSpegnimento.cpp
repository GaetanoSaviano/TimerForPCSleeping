#include <iostream>
#include <windows.h>
#include <stdlib.h>

using namespace std;

int main() {
    int time;
    cout << "In how many minutes do you want to shut down your PC ? ";
    cin >> time;
    
    int total_seconds = time * 60;
    int remaining_seconds = total_seconds;
    
    while (remaining_seconds > 0) {
        int minutes = remaining_seconds / 60;
        int seconds = remaining_seconds % 60;
        
        cout << "Time remaining: " << minutes << " minutes " << seconds << " seconds" << endl;
        
        Sleep(1000); // Wait for 1 second
        remaining_seconds--; // Decrease remaining time by 1 second
        system("cls"); // Clear the console screen for a cleaner display (Windows specific)
    }
    
    cout << "Bye Bye...Good Night!" << endl;
    system("shutdown -s -t 5 -f");

    return 0;
}

